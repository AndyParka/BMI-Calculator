/**
 * MyBMIServerService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package localhost.axis.MyBMIServer_jws;

public interface MyBMIServerService extends javax.xml.rpc.Service {
    public java.lang.String getMyBMIServerAddress();

    public localhost.axis.MyBMIServer_jws.MyBMIServer getMyBMIServer() throws javax.xml.rpc.ServiceException;

    public localhost.axis.MyBMIServer_jws.MyBMIServer getMyBMIServer(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
